package com.example.golden_ager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
