class UploadedImage {
  final String fileName, url;

  UploadedImage({
    required this.fileName,
    required this.url,
  });
}
